<?php
ob_start();
    #hostname,username,password,dbname
    $con = mysqli_connect("localhost","root","","Gimnasia");

    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    function getAtletas($query){
       global $con;

        if(empty($query)){
          $get_items = "select * from Atletas ORDER BY Name  ";
        }
        else{
          $get_items = $query;
        }

        $run_items = mysqli_query($con, $get_items);

        while($row_items=mysqli_fetch_array($run_items)){
            $item_ID = $row_items['ID'];

            $item_name = $row_items['Name'];
            $item_lastname = $row_items['LastName'];
            $item_age = $row_items['Age'];
            $item_category = $row_items['Category'];
            $item_nivel = $row_items['Nivel'];
            $item_club = $row_items['Club'];
            $item_birth = $row_items['Birth'];
            $item_entrenador = $row_items['Entrenador'];
            echo "
            <tr>
                <td>    $item_name $item_lastname   </td>
                <td>    $item_age   </td>
                <td>    $item_category  </td>
                <td>    $item_nivel </td>
                <td>    $item_club  </td>
                <td>    $item_birth </td>
                <td>  ";getEntrenadorNameToAtleta($item_entrenador); echo" </td>
                <td>
                  <form action='updateAtletas.php' method='post'>

                    <a href='updateAtletas.php?ID=$item_ID' class='btn btn-primary btn-round'>Editar</a>
                  </form>
                </td>
            </tr>
            ";

        }
    }

  function toUpdateAtletas(){
      global $con;
      $ID = $_GET['ID'];
      $get_items = "select * from Atletas WHERE ID = $ID ";

      $run_items = mysqli_query($con, $get_items);

      while($row_items=mysqli_fetch_array($run_items)){
          // $item_ID = $row_items['ID'];

          $item_name = $row_items['Name'];
          $item_lastname = $row_items['LastName'];
          $item_age = $row_items['Age'];
          $item_category = $row_items['Category'];
          $item_nivel = $row_items['Nivel'];
          $item_club = $row_items['Club'];
          $item_birth = $row_items['Birth'];
      }
  }

    function setAtleta(){
        global $con;
            $createFname = $_POST['firstName'];
            $createLname = $_POST['lastName'];
            $createAge = $_POST['age'];
            $createCategory = $_POST['category'];
            $createNivel = $_POST['nivel'];
            $createClub = $_POST['club'];
            $createBirth = $_POST['birth'];
            $createEntrenador = $_POST['entrenador'];

        if(!empty($createFname) && !empty($createLname) && !empty($createAge)
        && !empty($createCategory) && !empty($createNivel) && !empty($createClub) && !empty($createBirth))
          {
            $createUser = "INSERT INTO Atletas (Name, LastName, Age, Category, Nivel,Club, Birth, Entrenador)
            VALUES ('$createFname','$createLname','$createAge', '$createCategory', '$createNivel', '$createClub', '$createBirth','$createEntrenador')";

            $retval = mysqli_query($con,$createUser);

            if(! $retval ) {
                     die('Could not update data: ');
                  }

                  else{

                  echo "Updated data successfully\n";
                //   Para evitar que al darle refresh se vuelva añadir un atleta por accidente
                    unset($_POST);
                    unset($_REQUEST);
                    echo "<script>location.href='tableAtletas.php';</script>";
                }
          }
          else{
            echo "Falta de llenar";
          }
    }




  function setEntrenador(){
      global $con;
          $createFname = $_POST['firstName'];
          $createLname = $_POST['lastName'];
          // $createAge = $_POST['age'];
          // $createCategory = $_POST['category'];
          // $createNivel = $_POST['nivel'];
          $createClub = $_POST['club'];
          // $createBirth = $_POST['birth'];

      if(!empty($createFname) && !empty($createLname) && !empty($createClub) )
        {
          $createUser = "INSERT INTO Entrenadores (Name, LastName, Club)
          VALUES ('$createFname','$createLname', '$createClub')";

          $retval = mysqli_query($con,$createUser);

          if(! $retval ) {
                   die('Could not update data: ');
                }

                else{

                  echo "Updated data successfully\n";
                //   Para evitar que al darle refresh se vuelva añadir un atleta por accidente
                    unset($_POST);
                    unset($_REQUEST);
                    echo "<script>location.href='tableEntrenadores.php';</script>";
              }
        }
        else{
          echo "Falta de llenar";
        }
  }
// Para tomar el nombre del entrenador del ID y agregarlo al atleta
  function getEntrenadorNameToAtleta($ID){
    global $con;


      $get_items = "select * from Entrenadores WHERE ID = $ID  ";


    $run_items = mysqli_query($con, $get_items);

      while($row_items=mysqli_fetch_array($run_items)){
          $item_name = $row_items['Name'];
          $item_lastname = $row_items['LastName'];



          echo "
          $item_name $item_lastname

          ";
      }
  }
  function getEntrenadores($query){
    global $con;

    if(empty($query)){
      $get_items = "select * from Entrenadores ORDER BY Name  ";
    }
    else{
      $get_items = $query;
    }

    $run_items = mysqli_query($con, $get_items);

      while($row_items=mysqli_fetch_array($run_items)){
          $item_name = $row_items['Name'];
          $item_lastname = $row_items['LastName'];
          $ID = $row_items['ID'];
          $item_club = $row_items['Club'];

          echo "
          <tr>
              <td>    $item_name $item_lastname   </td>

              <td>    $item_club  </td>

              <td> <a href='tableEntrenadoresAtletas.php?ID=$ID' class='btn btn-primary btn-round'>Atletas</a> </td>

          </tr>
          ";
      }

}

function addEntrenadorToAtleta(){
  global $con;


    $get_items = "select * from Entrenadores ORDER BY Name  ";



  $run_items = mysqli_query($con, $get_items);

    while($row_items=mysqli_fetch_array($run_items)){
        $item_name = $row_items['Name'];
        $item_lastname = $row_items['LastName'];
        $item_ID = $row_items['ID'];



        echo "
        <option value='$item_ID'>
                $item_name $item_lastname
        </option>
        ";
    }

}

//Jueces ---------------------------------------------------------------------------------------------------------------
function setJuez(){
    global $con;
        $createFname = $_POST['firstName'];
        $createLname = $_POST['lastName'];
        // $createAge = $_POST['age'];
        // $createCategory = $_POST['category'];
        // $createNivel = $_POST['nivel'];
        //$createClub = $_POST['club'];
        // $createBirth = $_POST['birth'];

    if(!empty($createFname) && !empty($createLname) )
      {
        $createUser = "INSERT INTO Juez (Name, LastName)
        VALUES ('$createFname','$createLname')";

        $retval = mysqli_query($con,$createUser);

        if(! $retval ) {
                 die('Could not update data: ');
              }

              else{

                echo "Updated data successfully\n";
              //   Para evitar que al darle refresh se vuelva añadir un atleta por accidente
                  unset($_POST);
                  unset($_REQUEST);
                  echo "<script>location.href='tableJueces.php';</script>";
            }
      }
      else{
        echo "Falta de llenar";
      }
}

function getJueces($query){
  global $con;

  if(empty($query)){
    $get_items = "select * from Juez  ";
  }
  else{
    $get_items = $query;
  }

  $run_items = mysqli_query($con, $get_items);

    while($row_items=mysqli_fetch_array($run_items)){
        $item_name = $row_items['Name'];
        $item_lastname = $row_items['LastName'];



        echo "
        <tr>
            <td>    $item_name $item_lastname   </td>

            <td> <button type='submit' name='' class='btn btn-primary btn-round'>Editar</button> </td>

        </tr>
        ";
    }

}

// End Jueces ---------------------------------------------------------------------------------------------------------------

// Start Search ---------------------------------------------------------------------------------------------------------------
  function search($name, $table){
    global $con;

    $get_items = "select * from $table  where Name Like '%$name%' ";

    if($table == "Entrenadores"){
      getEntrenadores($get_items);
    }
    else if($table == "Atletas")
    {
      getAtletas($get_items);
    }
    else if($table == "Juez"){
      getJueces($get_items);
    }
  }



// End Search ---------------------------------------------------------------------------------------------------------------

//Start Tampoline---------------------------------------------------------------------------------------------------------------
  function getTrampolineEvents(){
    global $con;


    $get_items = "select * from Eventos Order BY ID DESC  ";


    $run_items = mysqli_query($con, $get_items);

      while($row_items=mysqli_fetch_array($run_items)){
        $item_name = $row_items['Name'];
        echo"<button type='submit' name='' class='btn btn-primary btn-round'>$item_name</button>";
      }
  }

  function Trampoline(){
    echo "<div class='col-md-4'>
    <div class='card card-user'>
      <div class='card-header'>
        <h5 class='card-title'>Eventos</h5>
      </div>
      <div class='card-body'>
        <form action='' method= 'post' >

          <div class='row-md-4'>
            ";

            getTrampolineEvents();

            echo"
            <div class='update ml-auto mr-auto'>
              <button type='submit' name='Tab' class='btn btn-primary btn-round'>+</button>

            </div>
          </div>
        </form>
      </div>
    </div>
</div>";
  }

  function newtabTrampoline(){
    echo "<div class='row-md-6'>
    <div class='card card-user'>
      <div class='card-header'>
        <h5 class='card-title'>Eventos</h5>
      </div>
      <div class='card-body'>
        <form action='' method= 'post' >

          <div class='col'>
          <div class='col-md-12 pr-1'>
          <div class='form-group'>
            <label>Nombre</label>
            <input type='text' class='form-control' name = 'Name' placeholder='Nombre' />
          </div>
            <div class='update ml-auto mr-auto'>
              <button type='submit' name='Crear' class='btn btn-primary btn-round'>Crear</button>
            </div>
          </div>
        </form>
      </div>
    </div>
</div>";
  }

  function addTrampolineEevent(){

    global $con;

    $Name = $_POST['Name'];
    $createUser = "INSERT INTO Eventos (Name) VALUES ('$Name')";

    $retval = mysqli_query($con,$createUser);
    if(! $retval ) {
      die('Could not update data: ');
    }

    else{

    //echo "Updated data successfully\n";
    //   Para evitar que al darle refresh se vuelva añadir un atleta por accidente
      unset($_POST);
      unset($_REQUEST);
      //echo "<script>location.href='tableEntrenadores.php';</script>";
    }
}
//End Trampoline ---------------------------------------------------------------------------------------------------------------

function entrenadoresHaveAtleta(){
  global $con;

    $ID = $_GET['ID'];
    $get_items = "select * from Atletas WHERE Entrenador = $ID ORDER BY Nivel   ";

  $run_items = mysqli_query($con, $get_items);

    while($row_items=mysqli_fetch_array($run_items)){
        $item_name = $row_items['Name'];
        $item_lastname = $row_items['LastName'];
        $item_age = $row_items['Age'];
        $item_category = $row_items['Category'];
        $item_nivel = $row_items['Nivel'];
        $item_club = $row_items['Club'];
        $item_birth = $row_items['Birth'];
        $item_entrenador = $row_items['Entrenador'];


        echo "
        <tr>
            <td>    $item_name $item_lastname   </td>
            <td>    $item_age   </td>
            <td>    $item_category  </td>
            <td>    $item_nivel </td>
            <td>    $item_club  </td>
            <td>    $item_birth </td>
            <td>  ";getEntrenadorNameToAtleta($item_entrenador); echo" </td>


        </tr>
        ";
    }
}
  ob_end_flush();
 ?>

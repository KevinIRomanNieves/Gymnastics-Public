<div class="sidebar-wrapper">
        <ul class="nav">
          <!-- <li>
            <a href="./dashboard.html">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li> -->
          <!-- <li>
            <a href="./icons.html">
              <i class="nc-icon nc-diamond"></i>
              <p>Icons</p>
            </a>
          </li> -->
          <!-- <li>
            <a href="./map.html">
              <i class="nc-icon nc-pin-3"></i>
              <p>Maps</p>
            </a>
          </li> -->
          <!-- <li>
            <a href="./notifications.html">
              <i class="nc-icon nc-bell-55"></i>
              <p>Notifications</p>
            </a>
          </li> -->

          <li >
            <a href="./Login.php">
              <i class="nc-icon nc-single-02"></i>
              <p>Login</p>
            </a>
          </li>
          <li>
            <a href="./userAtletas.php">
              <i class="nc-icon nc-single-02"></i>
              <p>Inscripción de Atletas</p>
            </a>
          </li>
          <li>
            <a href="./userEntrenadores.php">
              <i class="nc-icon nc-single-02"></i>
              <p>Entrenadores</p>
            </a>
          </li>
          <li>
            <a href="./userJueces.php">
              <i class="nc-icon nc-single-02"></i>
              <p>Jueces</p>
            </a>
          </li>
          <li >
            <a href="./tableAtletas.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Lista de Atletas</p>
            </a>
          </li>
          <li >
            <a href="./tableEntrenadores.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Entrenadores</p>
            </a>
          </li>
          <li>
            <a href="./tableJueces.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Lista de Jueces</p>
            </a>
          </li>
          <li >
            <a href="./Eventos.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Eventos</p>
            </a>
          </li>

          <!-- <li>
            <a href="./typography.html">
              <i class="nc-icon nc-caps-small"></i>
              <p>Typography</p>
            </a>
          </li> -->
          <!-- <li class="active-pro">
            <a href="./upgrade.html">
              <i class="nc-icon nc-spaceship"></i>
              <p>Upgrade to PRO</p>
            </a>
          </li> -->
        </ul>

      </div>
    </div>

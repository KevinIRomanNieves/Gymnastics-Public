-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 06, 2019 at 12:08 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Gimnasia`
--

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

CREATE TABLE `Admin` (
  `ID` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Atletas`
--

CREATE TABLE `Atletas` (
  `ID` int(100) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Age` int(50) NOT NULL,
  `Category` varchar(10) NOT NULL,
  `Nivel` int(10) NOT NULL,
  `Club` varchar(50) NOT NULL,
  `Birth` date NOT NULL,
  `Entrenador` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Atletas`
--

INSERT INTO `Atletas` (`ID`, `Name`, `LastName`, `Age`, `Category`, `Nivel`, `Club`, `Birth`, `Entrenador`) VALUES
(1, 'Jesus', 'Torres', 23, '6', 1, 'DGA', '1997-04-19', 1),
(2, 'Pedro', 'Gonzalez', 23, '6', 5, 'JK', '1999-01-06', 3),
(3, 'Zuly', 'Lopez', 18, '7 - 8', 3, 'ASPR', '2001-01-02', 1),
(4, 'Dionel', 'Torres', 18, '13', 5, 'ASPR', '2001-04-02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Entrenadores`
--

CREATE TABLE `Entrenadores` (
  `ID` int(100) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Club` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Entrenadores`
--

INSERT INTO `Entrenadores` (`ID`, `Name`, `LastName`, `Club`) VALUES
(1, 'Joseph', 'Velez', 'JK'),
(2, 'Dionel', 'Torres', 'GCFK'),
(3, 'Armando', 'Andujar', 'AA'),
(4, 'Adam', 'Velazquez', 'GCFK');

-- --------------------------------------------------------

--
-- Table structure for table `Eventos`
--

CREATE TABLE `Eventos` (
  `ID` int(11) NOT NULL,
  `Name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Eventos`
--

INSERT INTO `Eventos` (`ID`, `Name`) VALUES
(1, 'SanJuan'),
(2, 'Arecibo'),
(3, 'Hatillo'),
(4, 'Hatillo'),
(5, 'Ponce'),
(6, 'Bayamon');

-- --------------------------------------------------------

--
-- Table structure for table `Juez`
--

CREATE TABLE `Juez` (
  `ID` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Juez`
--

INSERT INTO `Juez` (`ID`, `Name`, `LastName`) VALUES
(1, 'Adam', 'Lopez'),
(2, 'Dionel', 'Lopez'),
(3, 'Joseph', 'Irizarry');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Atletas`
--
ALTER TABLE `Atletas`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Entrenadores`
--
ALTER TABLE `Entrenadores`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Eventos`
--
ALTER TABLE `Eventos`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Juez`
--
ALTER TABLE `Juez`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Admin`
--
ALTER TABLE `Admin`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Atletas`
--
ALTER TABLE `Atletas`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Entrenadores`
--
ALTER TABLE `Entrenadores`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Eventos`
--
ALTER TABLE `Eventos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `Juez`
--
ALTER TABLE `Juez`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
